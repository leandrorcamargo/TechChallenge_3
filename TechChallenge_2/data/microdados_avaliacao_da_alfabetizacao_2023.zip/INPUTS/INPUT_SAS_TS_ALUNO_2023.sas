/**************************************************************************/
/*  INEP/CETIC - Centro de Tecnologia, Inova��o e Ci�ncia de Dados     	  */      
/*                                   									  */	
/*  Coordena��o-Geral de Sistemas e Dados Educacionais (CGSDE)			  */
/*------------------------------------------------------------------------*/
/*  PROGRAMA:                                                             */
/*           INPUT_SAS_TS_ALUNO_2023.sas	                        	  */
/*------------------------------------------------------------------------*/
/* DESCRICAO: PROGRAMA PARA LEITURA DA TABELA TS_ALUNO DOS MICRODADOS DA  */
/* AEEB 2023                                                              */    
/*                                                                        */
/**************************************************************************/
/**************************************************************************/
/* Observa��o:                                                            */
/* 		                                                                  */
/* Para abrir os microdados � necess�rio salvar este programa e o arquivo */
/* TS_ALUNO.csv no diret�rio C:\ do computador.				      */
/*															 			  */                                           
/* Ao terminar esses procedimentos execute o programa salvo utilizando    */
/* as vari�veis de interesse.                                             */
/**************************************************************************/
/*				                  ATEN��O                                 */  
/**************************************************************************/
/* Este programa abre a base de alunos com os r�tulos das vari�veis de	  */
/* acordo com o dicion�rio de dados que comp�em os microdados. Para abrir */
/* os dados sem os r�tulos basta importar diretamente no SAS.			  */
/* 																	      */ 																          
/**************************************************************************/

proc format;
	Value TP_SERIE
			2='2� ano do Ensino Fundamental';

	Value TP_DEPENDENCIA
			1 = 'Federal'
			2 = 'Estadual'
			3 = 'Municipal'
			4 = 'Privada';

	Value IN_PRESENCA_LP
			0='Ausente'
			1='Presente';

	Value IN_PREENCHIMENTO_LP
			0='Prova n�o preenchida'
			1='Prova preenchida';

	Value IN_ALFABETIZADO
			0='N�o'
			1='Sim';

DATA WORK.TS_ALUNO_2023;
	INFILE 'C:\TS_ALUNO.csv' /*local do arquivo*/
	    LRECL=200
	    FIRSTOBS=2
	    DLM=';'
	    MISSOVER
	    DSD;

INPUT
        NU_ANO_AVALIACAO 	: ?? BEST4.
        CO_UF            	: ?? BEST2.
        SG_UF            	: $CHAR2.
        ID_ALUNO         	: ?? BEST8.
        TP_SERIE         	: ?? BEST1.
        ID_ESCOLA        	: ?? BEST8.
		TP_DEPENDENCIA		: ?? BEST1.
        CO_MUNICIPIO     	: ?? BEST7.
        NO_MUNICIPIO     	: $CHAR32.
        IN_PRESENCA_LP   	: ?? BEST1.
        IN_PREENCHIMENTO_LP : ?? BEST1.
        CO_CADERNO_LP    	: ?? BEST2.
        VL_PESO_ALUNO_LP 	: ?? COMMA11.
        VL_PROFICIENCIA_LP 	: ?? COMMA11.
        IN_ALFABETIZADO  	: ?? BEST1. ;

ATTRIB  
        TP_SERIE           		FORMAT = TP_SERIE.          
        TP_DEPENDENCIA          FORMAT = TP_DEPENDENCIA.     
        IN_PRESENCA_LP          FORMAT = IN_PRESENCA_LP.     
        IN_PREENCHIMENTO_LP     FORMAT = IN_PREENCHIMENTO_LP.
        IN_ALFABETIZADO         FORMAT = IN_ALFABETIZADO.;

LABEL
		NU_ANO_AVALIACAO 	= 'Ano de aplica��o da avalia��o estadual'
		CO_UF            	= 'C�digo da Unidade da Federa��o'
		SG_UF            	= 'Sigla da Unidade da Federa��o'
		ID_ALUNO         	= 'Identificador do Aluno'
		TP_SERIE         	= 'Ano Escolar'
		ID_ESCOLA        	= 'M�scara do C�digoo da Escola (c�digos fict�cios)'
		TP_DEPENDENCIA		= 'Depend�ncia Administrativa da Escola'
		CO_MUNICIPIO     	= 'C�digo do Munic�pio onde est� localizada a escola.'
		NO_MUNICIPIO     	= 'Nome do Munic�pio onde est� localizada a escola.'
		IN_PRESENCA_LP   	= 'Indicador de presen�a na prova de L�ngua Portuguesa (LP). '
		IN_PREENCHIMENTO_LP = 'Indicador de preenchimento da prova de L�ngua Portuguesa (LP). '
		CO_CADERNO_LP    	= 'C�digo do Caderno atribu�do ao aluno na prova de L�ngua Portuguesa (LP).'
		VL_PESO_ALUNO_LP 	= 'Peso do aluno na prova de L�ngua Portuguesa'
		VL_PROFICIENCIA_LP 	= 'Profici�ncia do aluno em L�ngua Portuguesa (LP) calculada na escala equalizada com o SAEB.'
		IN_ALFABETIZADO  	= 'Indica se o aluno, mediante o resultado da avalia��o estadual, � considerado alfabetizado.';
RUN;