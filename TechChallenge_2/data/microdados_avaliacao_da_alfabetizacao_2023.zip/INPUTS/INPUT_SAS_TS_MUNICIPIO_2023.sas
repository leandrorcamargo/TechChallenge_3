/**************************************************************************/
/*  INEP/CETIC - Centro de Tecnologia, Inova��o e Ci�ncia de Dados     	  */      
/*                                   									  */	
/*  Coordena��o-Geral de Sistemas e Dados Educacionais (CGSDE)			  */
/*------------------------------------------------------------------------*/
/*  PROGRAMA:                                                             */
/*           INPUT_SAS_TS_MUNICIPIO_2023.sas	                          */
/*------------------------------------------------------------------------*/
/* DESCRICAO: PROGRAMA PARA LEITURA DA TABELA TS_MUNICIPIO DOS MICRODADOS */
/* DA AEEB 2023                                                           */    
/*                                                                        */
/**************************************************************************/
/**************************************************************************/
/* Observa��o:                                                            */
/* 		                                                                  */
/* Para abrir os microdados � necess�rio salvar este programa e o arquivo */
/* TS_MUNICIPIO.csv no diret�rio C:\ do computador.				          */
/*															 			  */                                           
/* Ao terminar esses procedimentos execute o programa salvo utilizando    */
/* as vari�veis de interesse.                                             */
/**************************************************************************/
/*				                  ATEN��O                                 */  
/**************************************************************************/
/* Este programa abre a base de munic�pios com os r�tulos das vari�veis de*/
/* acordo com o dicion�rio de dados que comp�em os microdados. Para abrir */
/* os dados sem os r�tulos basta importar diretamente no SAS.			  */
/* 																	      */ 																          
/**************************************************************************/

proc format;
	Value TP_SERIE
			2='2� ano do Ensino Fundamental';

	Value ID_TIPO_REDE
			0 = 'Total (Federal, Estadual, Municipal e Privada)'
			1 = 'Federal'
			2 = 'Estadual'
			3 = 'Municipal'
			4 = 'Privada'
			5 = 'P�blica (Estadual e Municipal)'
			6 = 'P�blica (Federal, Estadual e Municipal)';


DATA WORK.TS_MUNICIPIO_2023;
	INFILE 'C:\TS_MUNICIPIO.csv' /*local do arquivo*/
	    LRECL=100
	    FIRSTOBS=2
	    DLM=';'
	    MISSOVER
	    DSD;

INPUT
        NU_ANO_AVALIACAO 		: ?? BEST4.
        CO_UF            		: ?? BEST2.
        SG_UF            		: $CHAR2.
        CO_MUNICIPIO     		: ?? BEST7.
        NO_MUNICIPIO     		: $CHAR32.
        TP_SERIE         		: ?? BEST1.
        ID_TIPO_REDE     		: ?? BEST1.
        PC_ALUNO_ALFABETIZADO 	: ?? COMMA5.
        VL_MEDIA_LP      		: ?? COMMA8. ;

ATTRIB  
        TP_SERIE		FORMAT = TP_SERIE.          
        ID_TIPO_REDE    FORMAT = ID_TIPO_REDE. ;

LABEL
		NU_ANO_AVALIACAO 		= 'Ano de aplica��o da avalia��o estadual'
		CO_UF            		= 'C�digo da Unidade da Federa��o'
		SG_UF            		= 'Sigla da Unidade da Federa��o'
		CO_MUNICIPIO     		= 'C�digo do Munic�pio'
		NO_MUNICIPIO     		= 'Nome do Munic�pio'
		TP_SERIE         		= 'Ano Escolar'
		ID_TIPO_REDE     		= 'Rede de ensino avaliada para constru��o do resultado'
		PC_ALUNO_ALFABETIZADO 	= 'Percentual dos alunos avalados no munic�pio que foram considerados, mediante o resultado da avalia��o estadual, como alfabetizados.'
		VL_MEDIA_LP      		= 'M�dia ponderada do munic�pio na avalia��o estadual na disciplina L�ngua Portuguesa (LP) equalizada com o SAEB.';
RUN;