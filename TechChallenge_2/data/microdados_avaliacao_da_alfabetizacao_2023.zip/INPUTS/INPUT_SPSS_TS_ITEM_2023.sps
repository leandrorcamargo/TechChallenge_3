/*****************************************************************************************************/
/*  INEP/CETIC-Centro de Tecnologia, Inova��o e Ci�ncia de Dados                             */ 
/*                                   			                                    */
/*  Coordena��o-Geral de Sistemas e Dados Educacionais (CGSDE)		*/
/*----------------------------------------------------------------------------------------------------------------------------*/
/*  PROGRAMA:                                                                                                      */
/*           INPUT_SPSS_INPUT_TS_ITEM_2023                                        	*/
/*----------------------------------------------------------------------------------------------------------------------------*/
/*DESCRICAO: PROGRAMA PARA LEITURA DA BASE DE ITENS		*/
/* TS_ITEM  		   				*/
/*****************************************************************************************************/
/*****************************************************************************************************/
/* Obs:                                                                                                                    */
/* 		                                                                                           */
/* Para abrir os microdados � necess�rio salvar este programa e o arquivo                    */
/* TS_ITEM.csv no diret�rio C:\ do computador.		                             	 */
/*							 */ 
/*							 */
/* Para a leitura dos microdados � necess�rio a sele��o do programa abaixo,               */
/* depois execute-o.						 */
/*							 */ 
/******************************************************************************************************/
/*                                                   ATEN��O                                                          */ 
/******************************************************************************************************/
/* Este programa abre a base de dados com os r�tulos das vari�veis de	                    */
/* acordo com o dicion�rio de dados que comp�em os microdados. Para abrir                */
/* os dados sem os r�tulos basta importar diretamente no SPSS.		  */
/* 							   */
/*******************************************************************************************************/
 
GET DATA
  /TYPE=TXT
  /FILE= "C:\TS_ITEM.csv" /*local do arquivo*/ 
  /DELCASE=LINE
  /DELIMITERS=";"
  /ARRANGEMENT=DELIMITED
  /FIRSTCASE=2
  /IMPORTCASE= ALL
  /VARIABLES=
  NU_ANO_AVALIACAO F4.0
  CO_UF F2.0
  SG_UF A2
  CO_BLOCO F2.0
  NU_POSICAO F2.0
  CO_ITEM F6.0
  TP_SERIE F1.0
  TP_DISCIPLINA F1.0
  NU_DESCRITOR_HABILIDADE A5
  DS_GABARITO A1
  TP_RESPOSTA_ITEM F1.0
  TP_MODELO_TRI F1.0
  NU_PARAM_A COMMA6.5
  NU_PARAM_B COMMA6.5
  NU_PARAM_C COMMA6.5
  NU_PARAM_B1 COMMA6.5
  NU_PARAM_B2 COMMA6.5
  NU_PARAM_B3 COMMA6.5
  NU_PARAM_B4 COMMA6.5
  IN_ITEM_COMUM F1.0.

CACHE.
EXECUTE.
DATASET NAME TS_ITEM_2023 WINDOW=FRONT.

VARIABLE LABELS
  NU_ANO_AVALIACAO "Ano de aplica��o da avalia��o estadual"
  CO_UF            	"C�digo da Unidade da Federa��o"
  SG_UF            	"Sigla da Unidade da Federa��o"
  CO_BLOCO         	"C�digo do Bloco"
  NU_POSICAO       	"Posi��o do item no Bloco."
  CO_ITEM          	"C�digo do item"
  TP_SERIE         	"Ano Escolar"
  TP_DISCIPLINA    	"Indica a disciplina a que corresponde o item"
  NU_DESCRITOR_HABILIDADE "Identificador do descritor do item"
  DS_GABARITO      	"Gabarito do Item"
  TP_RESPOSTA_ITEM 	"Tipo de resposta esperada para o Item"
  TP_MODELO_TRI    	"Modelos da Teoria de Resposta ao Item"
  NU_PARAM_A       	"Par�metro de discrimina��o."
  NU_PARAM_B       	"Par�metro de dificuldade."
  NU_PARAM_C       	"Par�metro de acerto ao acaso."
  NU_PARAM_B1      	"Par�metro de dificuldade da transi��o entre as categorias de erro e acerto parcial."
  NU_PARAM_B2      	"Par�metro de dificuldade da transi��o entre as categorias de acerto parcial e acerto total."
  NU_PARAM_B3      	"Par�metro de dificuldade da transi��o entre as categorias de acerto parcial e acerto total."
  NU_PARAM_B4      	"Par�metro de dificuldade da transi��o entre as categorias de acerto parcial e acerto total."
  IN_ITEM_COMUM	"Indica se � um item comum com a avalia��o do SAEB".
 
VALUE LABELS
  TP_SERIE
     2  "2� ano do Ensino Fundamental"
  /TP_DISCIPLINA
    1  "L�ngua Portuguesa (LP)"
  /TP_RESPOSTA_ITEM
    1  "Produ��o Textual"
    2  "Resposta Constru�da"
    3  "Resposta Objetiva"
    4  "Resposta Constru�da com Quesito"
  /TP_MODELO_TRI
    1  "M2PL: Modelo log�stico de 2 par�metros"
    2  "M3PL: Modelo Log�stico de 3 par�metros"
    3  "MRG: Modelo de resposta gradual"
    4  "M3P: modelo normal de 3 par�metros".