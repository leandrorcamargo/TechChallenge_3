/*****************************************************************************************************/
/*  INEP/CETIC-Centro de Tecnologia, Inova��o e Ci�ncia de Dados                             */ 
/*                                   			                                    */
/*  Coordena��o-Geral de Sistemas e Dados Educacionais (CGSDE)		*/
/*----------------------------------------------------------------------------------------------------------------------------*/
/*  PROGRAMA:                                                                                                      */
/*           INPUT_SPSS_INPUT_TS_ALUNO_2023                                        	*/
/*----------------------------------------------------------------------------------------------------------------------------*/
/*DESCRICAO: PROGRAMA PARA LEITURA DA BASE DE ALUNOS		*/
/* TS_ALUNO  		   				*/
/*****************************************************************************************************/
/*****************************************************************************************************/
/* Obs:                                                                                                                    */
/* 		                                                                                           */
/* Para abrir os microdados � necess�rio salvar este programa e o arquivo                    */
/* TS_ALUNO.csv no diret�rio C:\ do computador.		                             	 */
/*							 */ 
/*							 */
/* Para a leitura dos microdados � necess�rio a sele��o do programa abaixo,               */
/* depois execute-o.						 */
/*							 */ 
/******************************************************************************************************/
/*                                                   ATEN��O                                                          */ 
/******************************************************************************************************/
/* Este programa abre a base de dados com os r�tulos das vari�veis de	                    */
/* acordo com o dicion�rio de dados que comp�em os microdados. Para abrir                */
/* os dados sem os r�tulos basta importar diretamente no SPSS.		  */
/* 							   */
/*******************************************************************************************************/
 
GET DATA
  /TYPE=TXT
  /FILE= "C:\TS_ALUNO.csv" /*local do arquivo*/ 
  /DELCASE=LINE
  /DELIMITERS=";"
  /ARRANGEMENT=DELIMITED
  /FIRSTCASE=2
  /IMPORTCASE= ALL
  /VARIABLES=
  NU_ANO_AVALIACAO F4.0
  CO_UF F2.0
  SG_UF A2
  ID_ALUNO F8.0
  TP_SERIE F1.0
  ID_ESCOLA F8.0
  TP_DEPENDENCIA F1.0
  CO_MUNICIPIO F7.0
  NO_MUNICIPIO A32
  IN_PRESENCA_LP F1.0
  IN_PREENCHIMENTO_LP F1.0
  CO_CADERNO_LP F2.0
  VL_PESO_ALUNO_LP COMMA12.7
  VL_PROFICIENCIA_LP COMMA10.7
  IN_ALFABETIZADO F1.0.

CACHE.
EXECUTE.
DATASET NAME TS_ALUNO_2023 WINDOW=FRONT.

VARIABLE LABELS
  NU_ANO_AVALIACAO 	 "Ano de aplica��o da avalia��o estadual"
  CO_UF            		 "C�digo da Unidade da Federa��o"
  SG_UF            		 "Sigla da Unidade da Federa��o"
  ID_ALUNO         		 "Identificador do Aluno"
  TP_SERIE         		 "Ano Escolar"
  ID_ESCOLA        		 "M�scara do C�digoo da Escola (c�digos fict�cios)"
  TP_DEPENDENCIA		 "Depend�ncia Administrativa da Escola"
  CO_MUNICIPIO     		 "C�digo do Munic�pio onde est� localizada a escola."
  NO_MUNICIPIO     	 	"Nome do Munic�pio onde est� localizada a escola."
  IN_PRESENCA_LP   	 	"Indicador de presen�a na prova de L�ngua Portuguesa (LP). "
  IN_PREENCHIMENTO_LP 	"Indicador de preenchimento da prova de L�ngua Portuguesa (LP). "
  CO_CADERNO_LP    	 	"C�digo do Caderno atribu�do ao aluno na prova de L�ngua Portuguesa (LP)."
  VL_PESO_ALUNO_LP 	 "Peso do aluno na prova de L�ngua Portuguesa"
  VL_PROFICIENCIA_LP  	"Profici�ncia do aluno em L�ngua Portuguesa (LP) calculada na escala equalizada com o SAEB."
  IN_ALFABETIZADO  	 	"Indica se o aluno, mediante o resultado da avalia��o estadual, � considerado alfabetizado.".
 
VALUE LABELS
  TP_SERIE
    2 "2� ano do Ensino Fundamental"
  /TP_DEPENDENCIA
    1  "Federal"
    2  "Estadual"
    3  "Municipal"
    4  "Privada"
 /IN_PRESENCA_LP
    0 "Ausente"
    1 "Presente"
  /IN_PREENCHIMENTO_LP
     0 "Prova n�o preenchida"
     1 "Prova preenchida"
  /IN_ALFABETIZADO
     0 "N�o"
     1 "Sim".