/**************************************************************************/
/*  INEP/CETIC - Centro de Tecnologia, Inova��o e Ci�ncia de Dados     	  */      
/*                                   									  */	
/*  Coordena��o-Geral de Sistemas e Dados Educacionais (CGSDE)			  */
/*------------------------------------------------------------------------*/
/*  PROGRAMA:                                                             */
/*           INPUT_SAS_TS_ITEM_2023.sas	                          	  	  */
/*------------------------------------------------------------------------*/
/* DESCRICAO: PROGRAMA PARA LEITURA DA TABELA TS_ITEM DOS MICRODADOS DA   */
/* AEEB 2023                                                           */    
/*                                                                        */
/**************************************************************************/
/**************************************************************************/
/* Observa��o:                                                            */
/* 		                                                                  */
/* Para abrir os microdados � necess�rio salvar este programa e o arquivo */
/* TS_ITEM.csv no diret�rio C:\ do computador.				              */
/*															 			  */                                           
/* Ao terminar esses procedimentos execute o programa salvo utilizando    */
/* as vari�veis de interesse.                                             */
/**************************************************************************/
/*				                  ATEN��O                                 */  
/**************************************************************************/
/* Este programa abre a base de itens com os r�tulos das vari�veis de	  */
/* acordo com o dicion�rio de dados que comp�em os microdados. Para abrir */
/* os dados sem os r�tulos basta importar diretamente no SAS.			  */
/* 																	      */ 																          
/**************************************************************************/

proc format;
	Value TP_SERIE
			2='2� ano do Ensino Fundamental';

	Value TP_DISCIPLINA
			1 = 'L�ngua Portuguesa (LP)';

	Value TP_RESPOSTA_ITEM
			1 = 'Produ��o Textual'
			2 = 'Resposta Constru�da'
			3 = 'Resposta Objetiva'
			4 = 'Resposta Constru�da com Quesito';

	Value TP_MODELO_TRI
			1 = 'M2PL: Modelo log�stico de 2 par�metros'
			2 = 'M3PL: Modelo Log�stico de 3 par�metros'
			3 = 'MRG: Modelo de resposta gradual'
			4 = 'M3P: modelo normal de 3 par�metros';

DATA WORK.TS_ITEM_2023;
	INFILE 'C:\TS_ITEM.csv' /*local do arquivo*/
	    LRECL=100
	    FIRSTOBS=2
	    DLM=';'
	    MISSOVER
	    DSD;

INPUT
        NU_ANO_AVALIACAO 		: ?? BEST4.
        CO_UF            		: ?? BEST2.
        SG_UF            		: $CHAR2.
        CO_BLOCO         		: ?? BEST2.
        NU_POSICAO       		: ?? BEST2.
        CO_ITEM          		: ?? BEST6.
        TP_SERIE         		: ?? BEST1.
        TP_DISCIPLINA    		: ?? BEST1.
        NU_DESCRITOR_HABILIDADE : $CHAR5.
        DS_GABARITO      		: $CHAR1.
        TP_RESPOSTA_ITEM 		: ?? BEST1.
        TP_MODELO_TRI    		: ?? BEST1.
        NU_PARAM_A       		: ?? COMMA7.
        NU_PARAM_B       		: ?? COMMA7.
        NU_PARAM_C       		: ?? COMMA7.
        NU_PARAM_B1      		: ?? COMMA7.
        NU_PARAM_B2      		: ?? COMMA7.
        NU_PARAM_B3      		: ?? COMMA7.
        NU_PARAM_B4      		: ?? COMMA7.
        IN_ITEM_COMUM    		: ?? BEST1. ;

ATTRIB  
        TP_SERIE			FORMAT = TP_SERIE.          
        TP_DISCIPLINA    	FORMAT = TP_DISCIPLINA. 
		TP_RESPOSTA_ITEM	FORMAT = TP_RESPOSTA_ITEM.
		TP_MODELO_TRI		FORMAT = TP_MODELO_TRI.;

LABEL
		NU_ANO_AVALIACAO 	= 'Ano de aplica��o da avalia��o estadual'
		CO_UF            	= 'C�digo da Unidade da Federa��o'
		SG_UF            	= 'Sigla da Unidade da Federa��o'
		CO_BLOCO         	= 'C�digo do Bloco'
		NU_POSICAO       	= 'Posi��o do item no Bloco.'
		CO_ITEM          	= 'C�digo do item'
		TP_SERIE         	= 'Ano Escolar'
		TP_DISCIPLINA    	= 'Indica a disciplina a que corresponde o item'
		NU_DESCRITOR_HABILIDADE = 'Identificador do descritor do item'
		DS_GABARITO      	= 'Gabarito do Item'
		TP_RESPOSTA_ITEM 	= 'Tipo de resposta esperada para o Item'
		TP_MODELO_TRI    	= 'Modelos da Teoria de Resposta ao Item'
		NU_PARAM_A       	= 'Par�metro de discrimina��o.'
		NU_PARAM_B       	= 'Par�metro de dificuldade.'
		NU_PARAM_C       	= 'Par�metro de acerto ao acaso.'
		NU_PARAM_B1      	= 'Par�metro de dificuldade da transi��o entre as categorias de erro e acerto parcial.'
		NU_PARAM_B2      	= 'Par�metro de dificuldade da transi��o entre as categorias de acerto parcial e acerto total.'
		NU_PARAM_B3      	= 'Par�metro de dificuldade da transi��o entre as categorias de acerto parcial e acerto total.'
		NU_PARAM_B4      	= 'Par�metro de dificuldade da transi��o entre as categorias de acerto parcial e acerto total.'
		IN_ITEM_COMUM		= 'Indica se � um item comum com a avalia��o do SAEB';
RUN;