#--------------------------------------------------------
#  INEP/CETIC-Centro de Tecnologia, Inovação e Ciência de Dados 
#  Coordenação-Geral de Sistemas e Dados Educacionais (CGSDE)			
#--------------------------------------------------------

#--------------------------------------------------------
#  PROGRAMA:                                                                                                      
#           INPUT_R_TS_ESTADO_2023
#--------------------------------------------------------
#  DESCRIÇÃO:
#           PROGRAMA PARA LEITURA DA TABELA TS_ESTADOO DO AEEB 2023
#--------------------------------------------------------

#------------------------------------------------------------------------
# Observação:                                                                                                                    
#     Para abrir os microdados é necessário salvar o arquivo                    
#     TS_ESTADO.csv no diretório especificado. 
#     Ex. Windows C:\
#         Linux /home	                  
#------------------------------------------------------------------------

#------------------------------------------------------------------------
#                   ATENÇãO             
#------------------------------------------------------------------------
# Este programa abre a base de itens com os rótulos das variáveis de	                    
# acordo com o dicionário de dados que compõem os microdados. Para abrir 
# os dados sem os rótulos basta importar diretamente no R. 
#------------------------------------------------------------------------

# Instalação dos pacotes necessários
if(!require(data.table)) install.packages('data.table')
if(!require(forcats)) install.packages('forcats')

library(data.table)
library(forcats)

# Configuração do diretório de trabalho
setwd("C:\\")

# Carga dos microdados
ts_estado_2023 <- fread('TS_ESTADO.csv', sep = ';', na.strings = c("", "NA"), encoding = "Latin-1")

# Definição dos rótulos das variáveis
#ts_estado_2023$TP_SERIE <- factor(ts_estado_2023$TP_SERIE, levels = c(2), labels = c('2º ano do Ensino Fundamental'))
#ts_estado_2023$ID_TIPO_REDE <- factor(ts_estado_2023$ID_TIPO_REDE, levels = c(1,2,3,4,5,6), labels = c('Federal','Estadual','Municipal','Privada','Pública (Estadual e Municipal)','Pública (Federal, Estadual e Municipal)'))

# Atribui os labels para as variáveis
labels <- list(
  NU_ANO_AVALIACAO 		= 'Ano de aplicação da avaliação estadual',
  CO_UF            		= 'Código da Unidade da Federação',
  SG_UF            		= 'Sigla da Unidade da Federação',
  TP_SERIE         		= 'Ano Escolar',
  ID_TIPO_REDE     		= 'Rede de ensino avaliada para construção do resultado',
  PC_ALUNO_ALFABETIZADO 	= 'Percentual dos alunos avaliados no Estado (UF) que foram considerados, mediante o resultado da avaliação estadual, como alfabetizados.',
  VL_MEDIA_LP      		= 'Média ponderada do Estado (UF) na avaliação estadual na disciplina Língua Portuguesa (LP) equalizada com o SAEB.'
)

# Aplicando LABELS às colunas da tabela
for (var in names(labels)) {
  attr(ts_estado_2023[[var]], "label") <- labels[[var]]
}
