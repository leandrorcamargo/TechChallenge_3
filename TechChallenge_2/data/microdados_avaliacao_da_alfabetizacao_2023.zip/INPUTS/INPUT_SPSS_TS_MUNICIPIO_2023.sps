/*****************************************************************************************************/
/*  INEP/CETIC-Centro de Tecnologia, Inova��o e Ci�ncia de Dados                             */ 
/*                                   			                                    */
/*  Coordena��o-Geral de Sistemas e Dados Educacionais (CGSDE)		*/
/*----------------------------------------------------------------------------------------------------------------------------*/
/*  PROGRAMA:                                                                                                      */
/*           INPUT_SPSS_INPUT_TS_MUNICIPIO_2023                                        	*/
/*----------------------------------------------------------------------------------------------------------------------------*/
/*DESCRICAO: PROGRAMA PARA LEITURA DA BASE DE MUNIC�PIOS		*/
/* TS_MUNICIPIO 		   				*/
/*****************************************************************************************************/
/*****************************************************************************************************/
/* Observa��o:                                                                                                         */
/* 		                                                                                           */
/* Para abrir os microdados � necess�rio salvar este programa e o arquivo                    */
/* TS_MUNICIPIO.csv no diret�rio C:\ do computador.		                   */
/*							 */ 
/*							 */
/* Para a leitura dos microdados � necess�rio a sele��o do programa abaixo,               */
/* depois execute-o.						 */
/*							 */ 
/******************************************************************************************************/
/*                                                   ATEN��O                                                          */ 
/******************************************************************************************************/
/* Este programa abre a base de dados com os r�tulos das vari�veis de	                    */
/* acordo com o dicion�rio de dados que comp�em os microdados. Para abrir                */
/* os dados sem os r�tulos basta importar diretamente no SPSS.		  */
/* 							   */
/*******************************************************************************************************/
 
GET DATA
  /TYPE=TXT
  /FILE= "C:\TS_MUNICIPIO.csv" /*local do arquivo*/ 
  /DELCASE=LINE
  /DELIMITERS=";"
  /ARRANGEMENT=DELIMITED
  /FIRSTCASE=2
  /IMPORTCASE= ALL
  /VARIABLES=
  NU_ANO_AVALIACAO F4.0
  CO_UF F2.0
  SG_UF A2
  CO_MUNICIPIO F7.0
  NO_MUNICIPIO A32
  TP_SERIE F1.0
  ID_TIPO_REDE F1.0
  PC_ALUNO_ALFABETIZADO COMMA5.2
  VL_MEDIA_LP COMMA8.4.

CACHE.
EXECUTE.
DATASET NAME TS_MUNICIPIO_2023 WINDOW=FRONT.

VARIABLE LABELS
  NU_ANO_AVALIACAO 	 "Ano de aplica��o da avalia��o estadual"
  CO_UF            		 "C�digo da Unidade da Federa��o"
  SG_UF            		 "Sigla da Unidade da Federa��o"
  CO_MUNICIPIO     		 "C�digo do Munic�pio"
  NO_MUNICIPIO     		 "Nome do Munic�pio"
  TP_SERIE         		 "Ano Escolar"
  ID_TIPO_REDE     		 "Rede de ensino avaliada para constru��o do resultado"
  PC_ALUNO_ALFABETIZADO 	 "Percentual dos alunos avalados no Munic�pio que foram considerados, mediante o resultado da avalia��o estadual, como alfabetizados."
  VL_MEDIA_LP      		 "M�dia ponderada do Munic�pio na avalia��o estadual na disciplina L�ngua Portuguesa (LP) equalizada com o SAEB.".
 
VALUE LABELS
  TP_SERIE
    2 "2� ano do Ensino Fundamental"
  /ID_TIPO_REDE
    1  "Federal"
    2  "Estadual"
    3  "Municipal"
    4  "Privada"
    5  "P�blica (Estadual e Municipal)"
    6  "P�blica (Federal, Estadual e Municipal)".